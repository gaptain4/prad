import java.sql.*;
import javax.swing.*;
public class Login extends javax.swing.JFrame {

    /**
     * Creates new form Login
     */
    public Login() {
        initComponents();
    }

  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jPasswordField1 = new javax.swing.JPasswordField();
        jLabel1 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(null);

        jLabel2.setFont(new java.awt.Font("OCR A Extended", 1, 18)); // NOI18N
        jLabel2.setText("USERNAME");
        jLabel2.setToolTipText("USERNAME");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(90, 110, 98, 20);

        jLabel3.setFont(new java.awt.Font("OCR A Extended", 1, 18)); // NOI18N
        jLabel3.setText("PASSWORD");
        jLabel3.setToolTipText("PASSWORD");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(90, 170, 110, 20);

        jTextField1.setToolTipText("ENTER USERNAME");
        jPanel1.add(jTextField1);
        jTextField1.setBounds(210, 110, 140, 30);

        jButton1.setText("LOGIN");
        jButton1.setToolTipText("LOGIN TO YOUR ACCOUNT");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1);
        jButton1.setBounds(150, 230, 108, 21);

        jPasswordField1.setToolTipText("ENTER PASSWORD");
        jPanel1.add(jPasswordField1);
        jPasswordField1.setBounds(210, 170, 140, 30);

        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\ANIRUDH\\Desktop\\Java\\Prad\\LogoBtr.png")); // NOI18N
        jLabel1.setText("jLabel1");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(20, 20, 170, 70);

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/javaapplication3/ResizerImage590X315.jpg"))); // NOI18N
        jPanel1.add(jLabel5);
        jLabel5.setBounds(-10, -10, 620, 340);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 593, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 328, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        Connection con = null;
        Statement st = null;
        ResultSet rs = null;
        if(jTextField1.getText().equalsIgnoreCase("") || jPasswordField1.getText().equals(""))
        {
            JOptionPane.showMessageDialog(null,"Please Enter a Valid UserName and Password");
        }
        else
        {
        try
        {
            
            con = DriverManager.getConnection("jdbc:mysql://127.0.0.1/prad","root","Prad@123");
            st=con.createStatement();
            String user = jTextField1.getText();
            String password = jPasswordField1.getText();
            String s = "use prad;";
            st.executeUpdate(s);
            String sql= "SELECT * FROM LOGIN WHERE USERNAME = '"+user+"' AND PASSWORD = '"+password+"';";
            rs = st.executeQuery(sql);
            if(rs.next()==false) { 
                  System.out.print("No user");  
                  JOptionPane.showMessageDialog(null,"Wrong Username/Password!");
 
              }
            else
            {
                rs.beforeFirst();
                while(rs.next())
                {
                    rs.getString("USERNAME");
                     rs.getString("PASSWORD");
                    JOptionPane.showMessageDialog(null,"Login Successful");
                    
                     this.setVisible(false);
                    StaffPage s1 = new StaffPage();
                    s1.setVisible(true);
                    s1.jLabel2.setText(user);
                    
                   
                   
                }
            }
            
            
            
                    }
        catch(Exception e )
        {
            JOptionPane.showMessageDialog(null,e.getMessage());
        }
        
    }//GEN-LAST:event_jButton1ActionPerformed
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Login().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPasswordField jPasswordField1;
    public javax.swing.JTextField jTextField1;
    // End of variables declaration//GEN-END:variables
}
